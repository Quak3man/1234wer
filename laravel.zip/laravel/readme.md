# Laravel Quickstart - Intermediate - Task List With Authentication

https://laravel.com/docs/5.2/quickstart-intermediate
